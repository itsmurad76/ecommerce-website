document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    canvas.width = 400;
    canvas.height = 600;

    function drawBeaker(x, y, color) {
        ctx.fillStyle = color;
        ctx.fillRect(x, y, 50, 100);
    }

    function drawGame() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawBeaker(100, 300, 'blue');
        drawBeaker(200, 300, 'red');
    }

    setInterval(drawGame, 1000 / 60);
});